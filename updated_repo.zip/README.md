# Longbridge Trading Learning

This project contains code and configuration for learning and exploring realtime trading and analysis workflows.

## Prompt Hierarchy Design

To support intelligent prompting, this repository organizes prompt definitions into layered configuration files. The layers, from the most general to the most specific, are:

* **Foundation**: Global rules that apply across all modules. For example: unified terminology, time zone (Asia/Singapore), and prohibitions on leaking keys.
* **Domain**: Shared constraints and definitions for a business domain. The `analysis` domain defines how analysis outputs should be structured and what metrics to include.
* **Module**: Specific instructions for each module. For example, the `realtime_analysis` module describes how to read `symbols.csv` and generate analysis files.
* **Scenario**: Templates for common tasks within a module. The `analysis_intraday_snapshot` scenario provides a template for generating a snapshot report for a list of symbols over a time window.
* **Runtime**: Parameters supplied at runtime, such as the list of symbols or the window length. These variables can be substituted into the scenario templates.

All prompt files are stored under the `config/prompts` directory with subdirectories for `domain`, `modules`, and `scenarios`. A helper function `load_prompt` is provided in `utils_prompt.py` to merge these layers and apply runtime variables.