import os
import argparse
from datetime import datetime
from utils_symbols import read_symbols
from format_response import getBasicStatus, getStockDetails
from exchange_time_utils import add_exchange_time_fields, generate_deepseek_prompt
from deepseek_analysis import analyze_quote

def main():
    """
    Fetch real-time static info for a list of stock symbols, generate a DeepSeek prompt,
    invoke the DeepSeek analysis API, and write both the prompt and analysis to disk.

    Symbols are sourced from a CSV file (by default config/symbols.csv) with a header 'symbol'.
    The environment variables OUTPUT_DIR and DEEPSEEK_EXTRA_PROMPT can be used to override
    the output directory and append extra instructions to the prompt.
    """
    parser = argparse.ArgumentParser(description="Generate a DeepSeek analysis for stock symbols.")
    parser.add_argument(
        "--symbols-csv",
        default="config/symbols.csv",
        help="Path to the CSV file containing a 'symbol' column. Defaults to config/symbols.csv.",
    )
    parser.add_argument(
        "--output-dir",
        default=os.environ.get("OUTPUT_DIR", "."),
        help="Directory to place generated analysis files. Defaults to current directory or OUTPUT_DIR env.",
    )
    parser.add_argument(
        "--extra-prompt",
        default=os.environ.get("DEEPSEEK_EXTRA_PROMPT", ""),
        help="Additional instructions appended to the generated prompt.",
    )
    args = parser.parse_args()

    # Normalize and deduplicate symbols from CSV
    symbols = read_symbols(args.symbols_csv)

    # Retrieve static info using LongPort API
    resp = getBasicStatus(symbols)
    details = getStockDetails(resp)

    # Add local_time and utc_time fields based on exchange
    enriched = add_exchange_time_fields(details)

    # Construct a DeepSeek prompt from enriched records
    prompt = generate_deepseek_prompt(enriched)
    if args.extra_prompt:
        prompt = f"{prompt}\n\n额外提示：{args.extra_prompt}"

    # DeepSeek API expects a list of messages; we send a single user message
    messages = [prompt]
    analysis = analyze_quote(messages)

    # Ensure output directory exists and write results
    os.makedirs(args.output_dir, exist_ok=True)
    filename = f"analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    output_path = os.path.join(args.output_dir, filename)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("Prompt:\n")
        f.write(prompt)
        f.write("\n\nAnalysis & Suggestions:\n")
        f.write(analysis)

    print(f"Wrote analysis to {output_path}")

if __name__ == "__main__":
    main()