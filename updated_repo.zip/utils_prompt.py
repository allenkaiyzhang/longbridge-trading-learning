import os
import datetime as dt
from typing import Optional, Dict, Any
import yaml

"""
Utility for loading and merging hierarchical prompt definitions.

The prompt hierarchy includes:
  - foundation: project-wide constraints and policies
  - domain: domain-specific rules (e.g. analysis)
  - module: module-specific instructions (e.g. realtime_analysis)
  - scenario: scenario-specific templates (e.g. analysis_intraday_snapshot)

The load_prompt() function merges these layers and interpolates runtime variables.
"""

# Determine paths relative to this file
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(ROOT_DIR, "config")
PROMPTS_ROOT = os.path.join(CONFIG_DIR, "prompts")

def _read_yaml(path: str) -> Dict[str, Any]:
    """Return an empty dict if the YAML file does not exist."""
    if not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def _merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Merge two dictionaries shallowly; override values take precedence."""
    result = dict(base or {})
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(result.get(k), dict):
            result[k] = _merge(result[k], v)
        else:
            result[k] = v
    return result

def _render(template: Any, vars: Dict[str, Any]) -> Any:
    """Render a template string with {var} placeholders. Non-strings are returned as-is."""
    if not isinstance(template, str):
        return template
    rendered = template
    for k, v in vars.items():
        rendered = rendered.replace(f"{{{k}}}", str(v))
    return rendered

def load_prompt(
    module: Optional[str] = None,
    scenario: Optional[str] = None,
    runtime_vars: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Load and combine prompt layers with the following precedence (lowest to highest):
        1. foundation
        2. domain (currently always 'analysis')
        3. module (if provided)
        4. scenario (if provided)
        5. runtime variables (for template interpolation)

    Parameters
    ----------
    module : Optional[str]
        Name of the module whose prompt config is loaded from config/prompts/modules.
    scenario : Optional[str]
        Name of the scenario whose prompt config is loaded from config/prompts/scenarios.
    runtime_vars : Optional[Dict[str, Any]]
        Variables used to fill templates in the user prompt.

    Returns
    -------
    Dict[str, Any]
        Merged prompt definition with rendered templates.
    """
    # foundation layer
    foundation = _read_yaml(os.path.join(PROMPTS_ROOT, "foundation.yaml"))
    # domain layer: currently only one domain 'analysis'
    domain = _read_yaml(os.path.join(PROMPTS_ROOT, "domain", "analysis.yaml"))
    # module layer
    module_doc = _read_yaml(os.path.join(PROMPTS_ROOT, "modules", f"{module}.yaml")) if module else {}
    # scenario layer
    scenario_doc = _read_yaml(os.path.join(PROMPTS_ROOT, "scenarios", f"{scenario}.yaml")) if scenario else {}

    # merge layers
    merged: Dict[str, Any] = {}
    for layer in (foundation, domain, module_doc, scenario_doc):
        merged = _merge(merged, layer)

    # set default runtime variables
    vars: Dict[str, Any] = {
        "now": dt.datetime.now(dt.timezone(dt.timedelta(hours=8))).strftime("%Y-%m-%d %H:%M:%S"),
    }
    if runtime_vars:
        vars.update(runtime_vars)

    # render templated fields
    for key in ("system", "assistant_primer", "user_template"):
        if key in merged and merged[key]:
            merged[key] = _render(merged[key], vars)

    return merged